
//challange 1

// function printAverage(x){
//     sum = 0;
//     for(i = 0; i < x.length; i++) {
//         var z = sum + x[i];
//         sum = z
//     }
//     return sum / x.length;
//     // your code here
//  }
//  y = printAverage([1,2,3]);
//  console.log(y); // should log 2
   
//  y = printAverage([5,2,8]);
//  console.log(y); // should log 5

//challange 2

// function returnOddArray(){
//     var arr = []
//     num = 255
//     for(i = 1; i < num + 1; i++){
//         arr.push(i);
//     }
//     return arr;    // your code here
//  }
//  y = returnOddArray();
//  console.log(y); // should log [1,3,5,...,253,255]

//challange 3

// function squareValue(x){
    
//     for(i = 0; i < x.length; i++){
//        var y = (x[i]*x[i])
//        x[i] = y
//     }
//     // your code here
//     return x;
//  }
//  y = squareValue([1,2,3]);
//  console.log(y); // should log [1,4,9]
   
//  y = squareValue([2,5,8]);
//  console.log(y); // should log [4,25,64]

